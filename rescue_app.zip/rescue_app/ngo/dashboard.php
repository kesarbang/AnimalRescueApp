<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['ngo_id'])) {
    header("Location: login.php");
    exit();
}

$ngoName = $_SESSION['ngo_name'];

if (isset($_GET['rescue'])) {
    $id = intval($_GET['rescue']);
    $conn->query("UPDATE animal_reports SET status='Rescued' WHERE id='$id'");
    header("Location: dashboard.php");
    exit();
}

$result = $conn->query("SELECT * FROM animal_reports ORDER BY id DESC");
?>

<!DOCTYPE html>
<html lang="en" ng-app="ngoApp">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>NGO Dashboard</title>

<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">

<!-- jQuery -->
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>

<!-- AngularJS -->
<script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.8.2/angular.min.js"></script>

<style>
body{
font-family:Inter,sans-serif;
background:#f4f5f7;
margin:0;
color:#111;
}
.container{
width:92%;
max-width:1400px;
margin:auto;
}
header{
padding:25px 0;
display:flex;
justify-content:space-between;
align-items:center;
}
.logo{
font-size:24px;
font-weight:800;
color:#0a57d5;
}
.nav a{
margin-left:20px;
text-decoration:none;
color:#111;
font-weight:600;
}
.hero{
display:grid;
grid-template-columns:1fr 1fr;
gap:50px;
align-items:center;
padding:40px 0;
}
.hero h1{
font-size:62px;
font-weight:800;
line-height:1.1;
}
.hero h1 span{
color:#0a57d5;
font-style:italic;
}
.hero p{
font-size:18px;
color:#555;
line-height:1.7;
}
.btn{
display:inline-block;
padding:16px 26px;
background:#0a57d5;
color:#fff;
text-decoration:none;
border-radius:30px;
margin-top:20px;
font-weight:600;
}
.hero img{
width:100%;
border-radius:28px;
height:500px;
object-fit:cover;
}
.section{
padding:70px 0;
}
.title{
font-size:42px;
font-weight:800;
text-align:center;
margin-bottom:20px;
}
.search-box{
text-align:center;
margin-bottom:35px;
}
.search-box input{
padding:14px;
width:320px;
border:1px solid #ddd;
border-radius:25px;
font-size:15px;
}
.grid{
display:grid;
grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
gap:25px;
}
.card{
background:#fff;
border-radius:25px;
padding:25px;
box-shadow:0 10px 30px rgba(0,0,0,.05);
display:none;
}
.card img{
width:100%;
height:220px;
object-fit:cover;
border-radius:18px;
margin-bottom:15px;
}
.card h3{
margin:10px 0;
font-size:28px;
}
.tag{
padding:6px 14px;
border-radius:20px;
font-size:14px;
display:inline-block;
margin-bottom:10px;
}
.pending{
background:#fff3cd;
color:#856404;
}
.done{
background:#d4edda;
color:#155724;
}
.small{
color:#666;
margin:8px 0;
}
.action{
display:inline-block;
margin-top:15px;
padding:12px 18px;
background:#28a745;
color:#fff;
text-decoration:none;
border-radius:25px;
font-size:14px;
}
.counter{
text-align:center;
color:#0a57d5;
font-weight:700;
margin-bottom:20px;
font-size:18px;
}
</style>
</head>

<body ng-controller="ngoController">

<div class="container">

<header>
<div class="logo">Rescue Sanctuary</div>

<div class="nav">
<span><?php echo htmlspecialchars($ngoName); ?></span>
<a href="logout.php">Logout</a>
</div>
</header>

<div class="hero">

<div>
<h1>Help Save <span>Stray</span><br><span>Animals</span></h1>

<p>
Welcome <?php echo htmlspecialchars($ngoName); ?>.
Manage rescue requests and update status quickly.
</p>

<a href="#cases" class="btn scrollBtn">View Rescue Cases</a>
</div>

<div>
<img src="https://images.unsplash.com/photo-1517849845537-4d257902454a?auto=format&fit=crop&w=900&q=80">
</div>

</div>

<div class="section" id="cases">

<div class="title">Incoming Rescue Cases</div>

<!-- Angular Search -->
<div class="search-box">
<input type="text" ng-model="searchAnimal" placeholder="Search Animal Type">
</div>

<!-- Angular Count -->
<div class="counter">
Showing rescue cases for: [[ searchAnimal || 'All Animals' ]]
</div>

<div class="grid">

<?php while($row = $result->fetch_assoc()) { ?>

<div class="card animal-card"
ng-show="searchAnimal=='' || '<?php echo strtolower($row['animal_type']); ?>'.indexOf(searchAnimal.toLowerCase()) !== -1">

<img src="../uploads/<?php echo htmlspecialchars($row['photo']); ?>">

<?php if($row['status']=="Pending"){ ?>
<div class="tag pending">Pending</div>
<?php } else { ?>
<div class="tag done">Rescued</div>
<?php } ?>

<h3><?php echo htmlspecialchars($row['animal_type']); ?></h3>

<div class="small">
<b>Contact:</b>
<?php echo htmlspecialchars($row['contact_number']); ?>
</div>

<div class="small">
<b>Address:</b>
<?php echo htmlspecialchars($row['address']); ?>
</div>

<?php if($row['status']=="Pending"){ ?>
<a class="action" href="?rescue=<?php echo $row['id']; ?>">Mark Rescued</a>
<?php } ?>

</div>

<?php } ?>

</div>
</div>

</div>

<script>
/* AngularJS */
var app = angular.module('ngoApp', []);

app.config(function($interpolateProvider){
    $interpolateProvider.startSymbol('[[');
    $interpolateProvider.endSymbol(']]');
});

app.controller('ngoController', function($scope){
    $scope.searchAnimal = "";
});

/* jQuery */
$(document).ready(function(){

    /* Fade cards on load */
    $(".animal-card").fadeIn(800);

    /* Smooth scroll */
    $(".scrollBtn").click(function(e){
        e.preventDefault();

        $('html, body').animate({
            scrollTop: $("#cases").offset().top
        }, 800);
    });

});
</script>

</body>
</html>
<?php
session_start();
require_once '../db.php';

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $ngo_name = $conn->real_escape_string(trim($_POST['ngo_name']));
    $email = $conn->real_escape_string(trim($_POST['email']));
    $phone = $conn->real_escape_string(trim($_POST['phone']));
    $address = $conn->real_escape_string(trim($_POST['address']));
    $password = $_POST['password'];

    if (empty($ngo_name) || empty($email) || empty($phone) || empty($address) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        
        $check_email = $conn->query("SELECT id FROM ngos WHERE email = '$email'");
        if ($check_email->num_rows > 0) {
            $error = "Email already exists!";
        } else {
            $sql = "INSERT INTO ngos (ngo_name, email, phone, address, password) VALUES ('$ngo_name', '$email', '$phone', '$address', '$hashed_password')";
            if ($conn->query($sql) === TRUE) {
                $success = "NGO Registration successful. You can now login.";
            } else {
                $error = "Error: " . $conn->error;
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>NGO Registration - Pet Rescue</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="../index.php">Pet Rescue System</a>
        </div>
    </header>

    <div class="main-content">
        <div class="card" style="max-width: 500px;">
            <h2>NGO Registration</h2>
            <?php if(!empty($error)) echo "<div class='alert alert-error'>$error</div>"; ?>
            <?php if(!empty($success)) echo "<div class='alert alert-success'>$success</div>"; ?>
            
            <form action="" method="POST" onsubmit="return validateForm()">
                <div class="form-group">
                    <label>NGO Name</label>
                    <input type="text" name="ngo_name" id="ngo_name" required>
                </div>
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" name="email" id="email" required>
                </div>
                <div class="form-group">
                    <label>Phone</label>
                    <input type="text" name="phone" id="phone" required>
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <textarea name="address" id="address" rows="3" required></textarea>
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" name="password" id="password" required>
                </div>
                <button type="submit" class="btn">Register as NGO</button>
            </form>
            <div class="links">
                <p>Already have an NGO account? <a href="login.php">Login here</a></p>
                <p><a href="../index.php">Back to Home</a></p>
            </div>
        </div>
    </div>

    <script>
        function validateForm() {
            var name = document.getElementById('ngo_name').value;
            var email = document.getElementById('email').value;
            var phone = document.getElementById('phone').value;
            var address = document.getElementById('address').value;
            var password = document.getElementById('password').value;
            
            if (name.trim() == "" || email.trim() == "" || phone.trim() == "" || address.trim() == "" || password.trim() == "") {
                alert("Please fill all fields.");
                return false;
            }
            if (password.length < 6) {
                alert("Password must be at least 6 characters.");
                return false;
            }
            return true;
        }
    </script>
</body>
</html>

<?php
session_start();
require_once '../includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $result = $conn->query("SELECT * FROM ngos WHERE email = '$email'");
        if ($result->num_rows == 1) {
            $ngo = $result->fetch_assoc();
            if (password_verify($password, $ngo['password'])) {
                $_SESSION['ngo_id'] = $ngo['id'];        // matches dashboard check
                $_SESSION['ngo_name'] = $ngo['ngo_name'];
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "No NGO account found with this email.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>NGO Login - Pet Rescue</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <header><div class="container"><a href="../index.php">Pet Rescue System</a></div></header>
    <div class="main-content">
        <div class="card">
            <h2>NGO Login</h2>
            <?php if(!empty($error)) echo "<div class='alert alert-error'>$error</div>"; ?>
            <form action="" method="POST">
                <div class="form-group"><label>Email</label>
                    <input type="email" name="email" required></div>
                <div class="form-group"><label>Password</label>
                    <input type="password" name="password" required></div>
                <button type="submit" class="btn">Login</button>
            </form>
            <div class="links">
                <p>New NGO? <a href="register.php">Register here</a></p>
                <p><a href="../index.php">Back to Home</a></p>
            </div>
        </div>
    </div>
</body>
</html>
<?php include 'includes/header.php'; ?>

<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap');

    .report-wrap {
        font-family: 'Inter', sans-serif;
        background-color: #f8fafc;
        padding: 40px 20px;
        color: #334155;
    }
    
    .report-hero {
        display: flex;
        justify-content: space-between;
        align-items: center;
        max-width: 1000px;
        margin: 0 auto 40px auto;
        gap: 20px;
    }
    .hero-text {
        max-width: 600px;
    }
    .hero-text h1 {
        font-size: 3.5rem;
        font-weight: 800;
        margin: 0 0 10px 0;
        color: #0f172a;
        line-height: 1.1;
        letter-spacing: -1px;
    }
    .hero-text h1 span {
        color: #0d6efd;
    }
    .hero-text p {
        font-size: 1.1rem;
        color: #475569;
        margin: 0;
        line-height: 1.6;
    }
    .priority-btn {
        background-color: #f97316;
        color: #fff;
        padding: 14px 28px;
        border-radius: 50px;
        border: none;
        font-size: 0.95rem;
        font-weight: 700;
        letter-spacing: 0.5px;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        box-shadow: 0 4px 14px rgba(249, 115, 22, 0.3);
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .priority-btn:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 20px rgba(249, 115, 22, 0.4);
    }
    .report-card {
        max-width: 1000px;
        margin: 0 auto 40px auto;
        background: #ffffff;
        border-radius: 24px;
        box-shadow: 0 12px 36px rgba(0,0,0,0.06);
        display: grid;
        grid-template-columns: 1fr 1fr;
        overflow: hidden;
    }
    .rc-left, .rc-right {
        padding: 40px;
    }
    .rc-left {
        border-right: 1px solid #e2e8f0;
    }
    .rc-right {
        background: #f8fafc;
    }
    .section-title {
        font-size: 1.25rem;
        font-weight: 700;
        color: #1e293b;
        margin-bottom: 24px;
        display: flex;
        align-items: center;
        gap: 10px;
    }
    .section-title i {
        color: #0d6efd;
        font-size: 1.1em;
    }
    .form-group {
        margin-bottom: 24px;
        position: relative;
    }
    .form-group label {
        display: block;
        font-size: 0.9rem;
        font-weight: 600;
        color: #1e293b;
        margin-bottom: 8px;
    }
    .form-control {
        width: 100%;
        padding: 14px 16px;
        background: #f1f5f9;
        border: 2px solid transparent;
        border-radius: 12px;
        font-family: inherit;
        font-size: 0.95rem;
        color: #334155;
        transition: all 0.3s;
        box-sizing: border-box;
    }
    .form-control:focus {
        outline: none;
        background: #ffffff;
        border-color: #0d6efd;
        box-shadow: 0 0 0 4px rgba(13, 110, 253, 0.1);
    }
    textarea.form-control {
        resize: vertical;
    }
    .helper-text {
        font-size: 0.8rem;
        color: #64748b;
        margin-top: 6px;
        display: block;
    }
    .input-icon-wrap {
        position: relative;
    }
    .input-icon-wrap i {
        position: absolute;
        left: 16px;
        top: 50%;
        transform: translateY(-50%);
        color: #94a3b8;
        font-size: 1.1rem;
        pointer-events: none;
    }
    .input-icon-wrap .form-control {
        padding-left: 44px;
    }
    .row-2 {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
    }
    .submit-row {
        display: flex;
        align-items: center;
        gap: 20px;
        margin-top: 32px;
    }
    .btn-submit {
        background: #0d6efd;
        color: white;
        border: none;
        padding: 14px 32px;
        border-radius: 50px;
        font-size: 1rem;
        font-weight: 600;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        gap: 10px;
        box-shadow: 0 4px 12px rgba(13, 110, 253, 0.25);
        transition: all 0.2s;
    }
    .btn-submit:hover {
        transform: translateY(-2px);
        box-shadow: 0 6px 16px rgba(13, 110, 253, 0.35);
    }
    .secure-badge {
        display: flex;
        align-items: center;
        gap: 8px;
        color: #10b981;
        font-size: 0.9rem;
        font-weight: 500;
    }
    
    .upload-box {
        border: 2px dashed #cbd5e1;
        border-radius: 16px;
        padding: 40px 20px;
        text-align: center;
        background: #ffffff;
        position: relative;
        transition: all 0.3s;
        overflow: hidden;
    }
    .upload-box:hover, .upload-box.has-file {
        border-color: #0d6efd;
        background: #eff6ff;
    }
    .upload-input {
        position: absolute;
        top: 0; left: 0; right: 0; bottom: 0;
        width: 100%; height: 100%;
        opacity: 0;
        cursor: pointer;
        z-index: 10;
    }
    .upload-icon {
        font-size: 3rem;
        color: #0d6efd;
        margin-bottom: 16px;
    }
    .upload-box h4 {
        margin: 0 0 4px 0;
        color: #0f172a;
        font-size: 1.1rem;
    }
    .upload-box p {
        margin: 0;
        color: #64748b;
        font-size: 0.85rem;
    }
    .thumbnails {
        display: flex;
        justify-content: center;
        gap: 12px;
        margin-top: 24px;
        pointer-events: none;
    }
    .thumbnails img {
        width: 70px;
        height: 70px;
        border-radius: 10px;
        object-fit: cover;
        border: 1px solid #e2e8f0;
        box-shadow: 0 2px 4px rgba(0,0,0,0.05);
    }

    .features {
        max-width: 1000px;
        margin: 0 auto;
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 20px;
    }
    .feat-card {
        background: #ffffff;
        border-radius: 20px;
        padding: 24px;
        display: flex;
        align-items: flex-start;
        gap: 16px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.03);
    }
    .feat-icon {
        width: 48px;
        height: 48px;
        border-radius: 14px;
        background: #eff6ff;
        color: #0d6efd;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        flex-shrink: 0;
    }
    .feat-text h5 {
        margin: 0 0 6px 0;
        color: #0f172a;
        font-size: 1rem;
        font-weight: 700;
    }
    .feat-text p {
        margin: 0;
        color: #64748b;
        font-size: 0.85rem;
        line-height: 1.5;
    }
    
    .error {
        color: #ef4444;
        font-size: 0.85rem;
        margin-top: 6px;
        display: block;
    }

    @media (max-width: 768px) {
        .report-hero {
            flex-direction: column;
            text-align: center;
        }
        .report-card {
            grid-template-columns: 1fr;
        }
        .rc-left {
            border-right: none;
            border-bottom: 1px solid #e2e8f0;
        }
        .row-2, .features {
            grid-template-columns: 1fr;
        }
        .submit-row {
            flex-direction: column;
            align-items: stretch;
            text-align: center;
        }
        .btn-submit {
            justify-content: center;
        }
        .secure-badge {
            justify-content: center;
        }
    }
</style>

<div class="report-wrap">
    <div class="report-hero">
        <div class="hero-text">
            <h1>Every Second <span>Counts.</span></h1>
            <p>Your report can be the turning point for an animal in need. Provide as much detail as possible to help our rapid response team locate and assist.</p>
        </div>
        <button class="priority-btn" type="button">
            <i class="fas fa-exclamation-circle"></i> PRIORITY PROTOCOL
        </button>
    </div>

    <form id="reportForm" action="actions/submit_report.php" method="POST" enctype="multipart/form-data">
        <div class="report-card">
            <!-- Left Side: Inputs -->
            <div class="rc-left">
                <div class="section-title">
                    <i class="fas fa-file-signature"></i> What did you see?
                </div>
                
                <div class="form-group">
                    <textarea id="description" name="description" rows="4" class="form-control" placeholder="Describe the animal's condition, breed, and behavior..." required></textarea>
                    <small class="helper-text"><i class="fas fa-info-circle"></i> Mention any visible injuries or immediate dangers.</small>
                    <small id="descriptionError" class="error"></small>
                </div>

                <div class="row-2">
                    <div class="form-group">
                        <label for="location">Location</label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-map-marker-alt"></i>
                            <input type="text" id="location" name="location" class="form-control" placeholder="Street or Landmark" required>
                        </div>
                        <small id="locationError" class="error"></small>
                    </div>

                    <div class="form-group">
                        <label for="contact">Your Contact</label>
                        <div class="input-icon-wrap">
                            <i class="fas fa-mobile-alt"></i>
                            <input type="text" id="contact" name="contact" class="form-control" placeholder="+1 (555) 000-0000" required>
                        </div>
                        <small id="contactError" class="error"></small>
                    </div>
                </div>

                <div class="submit-row">
                    <button type="submit" class="btn-submit" id="submitBtn">
                        Submit Report <i class="fas fa-paper-plane"></i>
                    </button>
                    <div class="secure-badge">
                        <i class="fas fa-shield-alt"></i> Secure submission
                    </div>
                </div>
            </div>

            <!-- Right Side: Image Upload -->
            <div class="rc-right">
                <div class="section-title">
                    <i class="fas fa-camera"></i> Visual Evidence
                </div>
                <div class="form-group">
                    <div class="upload-box" id="uploadBox">
                        <input type="file" id="image" name="image" class="upload-input" accept="image/*" required>
                        <div class="upload-content">
                            <i class="fas fa-cloud-upload-alt upload-icon"></i>
                            <h4>Drag & Drop Image</h4>
                            <p>JPG, PNG or WEBP up to 10MB</p>
                        </div>
                        <div class="thumbnails">
                            <img src="https://images.unsplash.com/photo-1543466835-00a7907e9de1?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Dog UI sample">
                            <img src="https://images.unsplash.com/photo-1514888286974-6c03e2ca1dba?ixlib=rb-4.0.3&auto=format&fit=crop&w=100&q=80" alt="Cat UI sample">
                        </div>
                    </div>
                    <small id="imageError" class="error"></small>
                </div>
            </div>
        </div>
    </form>

    <div class="features">
        <div class="feat-card">
            <div class="feat-icon"><i class="fas fa-map-marked-alt"></i></div>
            <div class="feat-text">
                <h5>Live Tracking</h5>
                <p>We use geolocation to dispatch nearest team.</p>
            </div>
        </div>
        <div class="feat-card">
            <div class="feat-icon"><i class="fas fa-history"></i></div>
            <div class="feat-text">
                <h5>Status Updates</h5>
                <p>Receive SMS updates as our rescue team arrives.</p>
            </div>
        </div>
        <div class="feat-card">
            <div class="feat-icon"><i class="fas fa-user-shield"></i></div>
            <div class="feat-text">
                <h5>Privacy First</h5>
                <p>Your personal data is encrypted and secure.</p>
            </div>
        </div>
    </div>
</div>

<script>
    const fileInput = document.getElementById('image');
    const uploadBox = document.getElementById('uploadBox');

    fileInput.addEventListener('change', function() {
        if (this.files && this.files.length > 0) {
            uploadBox.classList.add('has-file');
            uploadBox.style.borderColor = '#10b981';
            document.getElementById('imageError').textContent = '';
        } else {
            uploadBox.classList.remove('has-file');
            uploadBox.style.borderColor = '';
        }
    });

    document.getElementById('reportForm').addEventListener('submit', function(e) {
        let isValid = true;

        const image = document.getElementById('image');
        const description = document.getElementById('description');
        const location = document.getElementById('location');
        const contact = document.getElementById('contact');

        // Reset errors
        document.querySelectorAll('.error').forEach(el => el.textContent = '');

        if (!image.value) {
            document.getElementById('imageError').textContent = 'Please select an image.';
            isValid = false;
        }

        if (description.value.trim() === '') {
            document.getElementById('descriptionError').textContent = 'Description is required.';
            isValid = false;
        }

        if (location.value.trim() === '') {
            document.getElementById('locationError').textContent = 'Location is required.';
            isValid = false;
        }

        if (contact.value.trim() === '') {
            document.getElementById('contactError').textContent = 'Contact number is required.';
            isValid = false;
        } else if (!/^[0-9+\-\s()]{7,15}$/.test(contact.value.trim())) {
            document.getElementById('contactError').textContent = 'Please enter a valid phone number.';
            isValid = false;
        }

        if (!isValid) {
            e.preventDefault();
            if (!image.value) {
                uploadBox.style.borderColor = '#ef4444';
            }
        } else {
            const submitBtn = document.getElementById('submitBtn');
            submitBtn.innerHTML = 'Submitting... <i class="fas fa-circle-notch fa-spin"></i>';
            submitBtn.style.opacity = '0.8';
            submitBtn.style.pointerEvents = 'none';
        }
    });
</script>


<?php include 'includes/footer.php'; ?>

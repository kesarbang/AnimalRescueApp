<?php
require_once 'includes/db.php';
require_once 'includes/header.php';

$query = "SELECT * FROM reports ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);
?>

<style>
/* Base Styles */
.view-reports-page {
    background-color: #f8fafc;
    padding: 60px 20px;
    font-family: 'Inter', sans-serif;
    color: #334155;
    min-height: calc(100vh - 150px);
}

.reports-header {
    max-width: 1200px;
    margin: 0 auto 40px auto;
}

.reports-header h2 {
    font-size: 2.5rem;
    font-weight: 800;
    color: #0f172a;
    margin-bottom: 10px;
}

.reports-header p.subtitle {
    font-size: 1.1rem;
    color: #64748b;
    margin-bottom: 30px;
}

.controls-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    flex-wrap: wrap;
    gap: 20px;
}

.filter-buttons {
    display: flex;
    gap: 10px;
    flex-wrap: wrap;
}

.filter-btn {
    padding: 8px 16px;
    border-radius: 20px;
    border: none;
    background-color: #f1f5f9;
    color: #64748b;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.2s ease;
}

.filter-btn.active {
    background-color: #2563eb;
    color: white;
}

.filter-btn:hover:not(.active) {
    background-color: #e2e8f0;
}

.toggle-buttons {
    display: flex;
    gap: 10px;
    background-color: #f1f5f9;
    padding: 5px;
    border-radius: 20px;
}

.toggle-btn {
    padding: 6px 16px;
    border-radius: 15px;
    border: none;
    background-color: transparent;
    color: #64748b;
    font-size: 0.9rem;
    font-weight: 500;
    display: flex;
    align-items: center;
    gap: 6px;
    cursor: pointer;
    transition: all 0.2s;
}

.toggle-btn.active {
    background-color: white;
    color: #0f172a;
    box-shadow: 0 1px 3px rgba(0,0,0,0.1);
}

.reports-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
    gap: 30px;
    max-width: 1200px;
    margin: 0 auto;
}

.report-card {
    background: white;
    border-radius: 20px;
    overflow: hidden;
    position: relative;
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05), 0 8px 10px -6px rgba(0,0,0,0.01);
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.report-card:hover {
    transform: translateY(-5px);
    box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1), 0 10px 10px -5px rgba(0,0,0,0.04);
}

.card-image-wrap {
    position: relative;
    height: 220px;
    width: 100%;
}

.card-image-wrap img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.placeholder-img {
    width: 100%;
    height: 100%;
    background: #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #94a3b8;
    font-weight: 500;
}

.status-badge {
    position: absolute;
    top: 15px;
    left: 15px;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 700;
    text-transform: uppercase;
    letter-spacing: 0.05em;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.status-pending {
    background-color: #d97706; /* orange */
    color: white;
}

.status-inprogress {
    background-color: #abc1f2; /* light blue */
    color: #1e3a8a;
}

.status-rescued {
    background-color: #10b981; /* green */
    color: white;
}

.card-body {
    padding: 24px;
    flex-grow: 1;
    display: flex;
    flex-direction: column;
}

.card-title-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 12px;
}

.card-title-row h3 {
    margin: 0;
    font-size: 1.25rem;
    font-weight: 700;
    color: #0f172a;
}

.tag-badge {
    background-color: #ffedd5; /* light orange */
    color: #c2410c;
    padding: 4px 10px;
    border-radius: 20px;
    font-size: 0.75rem;
    font-weight: 600;
}

.card-desc {
    color: #64748b;
    font-size: 0.95rem;
    line-height: 1.6;
    margin-bottom: 24px;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    flex-grow: 1;
}

.card-meta {
    display: flex;
    flex-direction: column;
    gap: 12px;
    margin-bottom: 24px;
}

.meta-item {
    display: flex;
    align-items: center;
    gap: 10px;
    color: #475569;
    font-size: 0.9rem;
}

.meta-item svg {
    width: 18px;
    height: 18px;
    color: #2563eb;
    flex-shrink: 0;
}

.btn-details {
    width: 100%;
    padding: 12px;
    background-color: #1d4ed8;
    color: white;
    border: none;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.95rem;
    cursor: pointer;
    transition: background-color 0.2s;
    text-align: center;
    text-decoration: none;
    display: inline-block;
}

.btn-details:hover {
    background-color: #1e3a8a;
    color: white;
}

/* Specific button styles for rescued animals */
.btn-details.btn-success {
    background-color: #e2e8f0;
    color: #334155;
}

.btn-details.btn-success:hover {
    background-color: #cbd5e1;
}

/* Special Card */
.special-card {
    border: 2px dashed #cbd5e1;
    background-color: transparent;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    text-align: center;
    padding: 40px 24px;
    box-shadow: none;
    min-height: 350px;
}

.special-card:hover {
    border-color: #94a3b8;
    background-color: white;
    transform: none;
    box-shadow: 0 10px 25px -5px rgba(0,0,0,0.05);
}

.special-card-icon {
    width: 64px;
    height: 64px;
    margin-bottom: 24px;
    color: #94a3b8;
    position: relative;
}

.special-card-icon svg {
    width: 100%;
    height: 100%;
}

.special-card-icon::after {
    content: '+';
    position: absolute;
    top: -5px;
    right: -5px;
    font-size: 24px;
    font-weight: bold;
    color: #94a3b8;
}

.special-card h3 {
    margin: 0 0 12px 0;
    font-size: 1.25rem;
    font-weight: 700;
    color: #0f172a;
}

.special-card p {
    color: #64748b;
    font-size: 0.95rem;
    line-height: 1.6;
    margin-bottom: 30px;
    max-width: 250px;
}

.btn-report-special {
    background-color: #e2e8f0;
    color: #1e293b;
    padding: 12px 30px;
    border-radius: 20px;
    font-weight: 600;
    font-size: 0.95rem;
    text-decoration: none;
    transition: all 0.2s ease;
}

.btn-report-special:hover {
    background-color: #cbd5e1;
    color: #0f172a;
}

/* Pagination */
.pagination {
    display: flex;
    justify-content: center;
    align-items: center;
    gap: 10px;
    margin-top: 60px;
}

.page-link {
    width: 36px;
    height: 36px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    color: #0f172a;
    text-decoration: none;
    font-weight: 600;
    font-size: 0.95rem;
    transition: all 0.2s;
}

.page-link:hover {
    background-color: #f1f5f9;
}

.page-link.active {
    background-color: #1d4ed8;
    color: white;
}

.page-arrow {
    color: #94a3b8;
    display: flex;
    align-items: center;
    justify-content: center;
}

.page-arrow svg {
    width: 18px;
    height: 18px;
}

.page-dots {
    color: #94a3b8;
    font-weight: 600;
}

/* Utilities */
@media (max-width: 768px) {
    .controls-bar {
        flex-direction: column;
        align-items: flex-start;
    }
    
    .reports-grid {
        grid-template-columns: 1fr;
    }
}
</style>

<div class="view-reports-page">
    <div class="reports-header controls-section">
        <h2>Rescue Reports</h2>
        <p class="subtitle">Real-time updates on active rescue missions. Every report brings us one step closer to providing a safe haven for animals in need.</p>
        
        <div class="controls-bar">
            <div class="filter-buttons">
                <button class="filter-btn active">All Reports</button>
                <button class="filter-btn">Dogs</button>
                <button class="filter-btn">Cats</button>
                <button class="filter-btn">Birds</button>
                <button class="filter-btn">Exotic</button>
            </div>
            <div class="toggle-buttons">
                <button class="toggle-btn active">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                    Grid
                </button>
                <button class="toggle-btn">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="8" y1="6" x2="21" y2="6"></line><line x1="8" y1="12" x2="21" y2="12"></line><line x1="8" y1="18" x2="21" y2="18"></line><line x1="3" y1="6" x2="3.01" y2="6"></line><line x1="3" y1="12" x2="3.01" y2="12"></line><line x1="3" y1="18" x2="3.01" y2="18"></line></svg>
                    List
                </button>
            </div>
        </div>
    </div>

    <div class="reports-grid">
        <?php if ($result && mysqli_num_rows($result) > 0): ?>
            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                <?php 
                $status = trim($row['status']);
                $statusClass = 'status-inprogress';
                $statusText = $status;
                $btnClass = '';
                $btnText = 'VIEW DETAILS';
                
                if (strtolower($status) === 'pending') {
                    $statusClass = 'status-pending';
                } elseif (strtolower($status) === 'resolved' || strtolower($status) === 'rescued') {
                    $statusClass = 'status-rescued';
                    $btnClass = 'btn-success';
                    $btnText = 'VIEW SUCCESS STORY';
                }
                
                // Determine a random tag badge placeholder since it's not in DB
                $tags = ['Scared', 'Injured', 'Friendly', 'Needs Help', 'Lost'];
                $randomTag = $tags[array_rand($tags)];
                ?>
                <div class="report-card">
                    <div class="card-image-wrap">
                        <div class="status-badge <?php echo $statusClass; ?>">
                            <?php echo htmlspecialchars($statusText); ?>
                        </div>
                        <?php if (!empty($row['image'])): ?>
                            <img src="uploads/<?php echo htmlspecialchars($row['image']); ?>" alt="Reported Animal">
                        <?php else: ?>
                            <div class="placeholder-img">No Image Provided</div>
                        <?php endif; ?>
                    </div>
                    
                    <div class="card-body">
                        <div class="card-title-row">
                            <h3>Animal Report</h3>
                            <span class="tag-badge"><?php echo $randomTag; ?></span>
                        </div>
                        
                        <p class="card-desc"><?php echo htmlspecialchars($row['description']); ?></p>
                        
                        <div class="card-meta">
                            <div class="meta-item">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>
                                <span><?php echo htmlspecialchars($row['location'] ? $row['location'] : 'Location unknown'); ?></span>
                            </div>
                            <div class="meta-item">
                                <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                                <span>Reported by <?php echo htmlspecialchars($row['contact'] ? $row['contact'] : 'Anonymous'); ?></span>
                            </div>
                        </div>
                        
                        <a href="#" class="btn-details <?php echo $btnClass; ?>"><?php echo $btnText; ?></a>
                    </div>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <div style="grid-column: 1 / -1; text-align: center; padding: 40px; color: #64748b;">
                <p>No active reports available at the moment.</p>
            </div>
        <?php endif; ?>
        
        <!-- Notice something special card -->
        <div class="report-card special-card">
            <div class="special-card-icon">
                <svg viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z"/></svg>
            </div>
            <h3>Notice something?</h3>
            <p>Help us expand our sanctuary by reporting animals in need in your area.</p>
            <a href="report.php" class="btn-report-special">REPORT ANIMAL</a>
        </div>
    </div>

    <div class="pagination">
        <a href="#" class="page-link page-arrow" style="border: none;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 18 9 12 15 6"></polyline></svg>
        </a>
        <a href="#" class="page-link active">1</a>
        <a href="#" class="page-link">2</a>
        <a href="#" class="page-link">3</a>
        <span class="page-dots">...</span>
        <a href="#" class="page-link">12</a>
        <a href="#" class="page-link page-arrow" style="border: none;">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </a>
    </div>
</div>

<?php
require_once 'includes/footer.php';
?>

<?php
session_start();
require_once '../includes/db.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $description = mysqli_real_escape_string($conn, $_POST['description'] ?? '');
    $location = mysqli_real_escape_string($conn, $_POST['location'] ?? '');
    $contact = mysqli_real_escape_string($conn, $_POST['contact'] ?? '');
    $status = 'Pending';
    
    $imageFileName = '';
    
    // Handle the image upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] == UPLOAD_ERR_OK) {
        $uploadDir = '../uploads/';
        
        // Ensure the upload directory exists
        if (!is_dir($uploadDir)) {
            mkdir($uploadDir, 0755, true);
        }
        
        // Generate a unique file name to avoid overwriting existing files
        $fileName = time() . '_' . basename($_FILES['image']['name']);
        $targetFilePath = $uploadDir . $fileName;
        $fileType = strtolower(pathinfo($targetFilePath, PATHINFO_EXTENSION));
        
        // Validate file type
        $allowedTypes = array('jpg', 'jpeg', 'png', 'gif');
        if (in_array($fileType, $allowedTypes)) {
            // Upload the file to the server
            if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFilePath)) {
                $imageFileName = $fileName;
            } else {
                die("Error: Could not move the uploaded file. Ensure the uploads directory is writable.");
            }
        } else {
            die("Error: Only JPG, JPEG, PNG & GIF files are allowed.");
        }
    }
    
    // Insert data into the database
    $query = "INSERT INTO reports (image, description, location, contact, status) 
              VALUES ('$imageFileName', '$description', '$location', '$contact', '$status')";
              
    if (mysqli_query($conn, $query)) {
        // Redirect to view reports page on success
        header("Location: ../view_reports.php");
        exit();
    } else {
        die("Error writing to database: " . mysqli_error($conn));
    }
    
} else {
    // If not a POST request, redirect to the report form
    header("Location: ../report.php");
    exit();
}
?>

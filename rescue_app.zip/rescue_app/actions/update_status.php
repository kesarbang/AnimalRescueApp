<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: ../admin/login.php");
    exit();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_once '../includes/db.php';
    
    $report_id = isset($_POST['report_id']) ? intval($_POST['report_id']) : 0;
    $status = isset($_POST['status']) ? trim($_POST['status']) : '';
    
    $allowed_statuses = ['Pending', 'In Progress', 'Rescued'];
    
    if ($report_id > 0 && in_array($status, $allowed_statuses)) {
        $status = mysqli_real_escape_string($conn, $status);
        
        $query = "UPDATE reports SET status = '$status' WHERE id = $report_id";
        
        if (mysqli_query($conn, $query)) {
            $_SESSION['message'] = "Report status updated successfully!";
        } else {
            $_SESSION['error'] = "Error updating status: " . mysqli_error($conn);
        }
        
    } else {
        $_SESSION['error'] = "Invalid input.";
    }
    
    mysqli_close($conn);
}

header("Location: ../admin/dashboard.php");
exit();
?>

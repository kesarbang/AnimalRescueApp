<?php include 'db.php'; session_start(); ?>

<form method="POST">
<input type="email" name="email" required>
<input type="password" name="password" required>

<button name="login">Login</button>
</form>

<?php
if(isset($_POST['login'])) {
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $res = $conn->query("SELECT * FROM ngos WHERE email='$email'");
    $ngo = $res->fetch_assoc();

    if($ngo && password_verify($pass, $ngo['password'])) {
        $_SESSION['ngo'] = $ngo['id'];
        echo "Login Success";
    } else {
        echo "Invalid Credentials";
    }
}
?>
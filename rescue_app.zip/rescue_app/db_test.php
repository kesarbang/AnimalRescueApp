<?php

$conn = new mysqli("127.0.0.1","root","","rescue_db",3307);


if ($conn->connect_error) {
    die("❌ Connection failed: " . $conn->connect_error);
} else {
    echo "✅ Connected to rescue_db successfully!<br>";
}

// Try creating a table
$result = $conn->query("CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)");

if ($result) {
    echo "✅ Users table created!";
} else {
    echo "❌ Table creation failed: " . $conn->error;
}
?>
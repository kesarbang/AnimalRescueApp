<?php
// Get the current page name for active menu highlighting
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Stray Animal Rescue and Reporting System</title>
    <!-- Link to the main stylesheet (relative to root files like index.php) -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="main-header">
        <nav class="navbar">
            <div class="logo">
                <a href="index.php">Animal Rescue</a>
            </div>
            
            <!-- Mobile Menu Hamburger -->
            <div class="menu-toggle" id="mobile-menu" onclick="toggleMenu()">
                &#9776;
            </div>
            
            <!-- Navigation Links -->
            <ul class="nav-links" id="nav-list">
                <li>
                    <a href="index.php" class="<?php echo ($current_page == 'index.php') ? 'active' : ''; ?>">Home</a>
                </li>
                <li>
                    <a href="report.php" class="<?php echo ($current_page == 'report.php') ? 'active' : ''; ?>">Report Animal</a>
                </li>
                <li>
                    <a href="view_reports.php" class="<?php echo ($current_page == 'view_reports.php') ? 'active' : ''; ?>">View Reports</a>
                </li>
                <li>
                    <a href="contact.php" class="<?php echo ($current_page == 'contact.php') ? 'active' : ''; ?>">Contact</a>
                </li>
            </ul>

            <!-- Search and Profile Icon -->
            <div class="nav-actions" style="display: flex; align-items: center; gap: 1.5rem;">
                <div class="search-bar" style="position: relative; display: flex; align-items: center; background: #f1f5f9; border-radius: 9999px; padding: 0.5rem 1rem;">
                    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="margin-right: 0.5rem;"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <input type="text" placeholder="Search reports..." style="border: none; background: transparent; outline: none; font-size: 0.9rem; color: #334155; width: 130px;">
                </div>
                <a href="#" class="profile-icon" style="display: flex; align-items: center; justify-content: center; width: 36px; height: 36px; border-radius: 50%; background: #e2e8f0; color: #475569; text-decoration: none;">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                </a>
            </div>
        </nav>
    </header>

    <!-- Simple JS for Responsive Menu Toggle -->
    <script>
        function toggleMenu() {
            const navList = document.getElementById("nav-list");
            if (navList.style.display === "flex") {
                navList.style.display = "none";
            } else {
                navList.style.display = "flex";
                navList.style.flexDirection = "column";
            }
        }
    </script>
    
    <!-- Main Content Container Start -->
    <main class="container">

<?php include 'db.php'; ?>

<form method="POST">
<input type="text" name="ngo_name" placeholder="NGO Name" required>
<input type="email" name="email" required>
<input type="text" name="phone" required>
<input type="text" name="address" required>
<input type="password" name="password" required>

<button name="register">Register</button>
</form>

<?php
if(isset($_POST['register'])) {
    $name = $_POST['ngo_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $addr = $_POST['address'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $conn->query("INSERT INTO ngos (ngo_name,email,phone,address,password)
    VALUES ('$name','$email','$phone','$addr','$pass')");

    echo "NGO Registered";
}
?>
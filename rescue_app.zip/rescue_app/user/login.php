<?php
session_start();
require_once '../includes/db.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $conn->real_escape_string(trim($_POST['email']));
    $password = $_POST['password'];

    if (empty($email) || empty($password)) {
        $error = "All fields are required.";
    } else {
        $result = $conn->query("SELECT * FROM users WHERE email = '$email'");
        if ($result->num_rows == 1) {
            $user = $result->fetch_assoc();
            if (password_verify($password, $user['password'])) {
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['user_name'] = $user['name'];
                header("Location: dashboard.php");
                exit();
            } else {
                $error = "Invalid password.";
            }
        } else {
            $error = "No account found with this email.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Login - Pet Rescue</title>
    <link rel="stylesheet" href="../style.css">
</head>
<body>
    <header><div class="container"><a href="../index.php">Pet Rescue System</a></div></header>
    <div class="main-content">
        <div class="card">
            <h2>User Login</h2>
            <?php if(!empty($error)) echo "<div class='alert alert-error'>$error</div>"; ?>
            <form action="" method="POST">
                <div class="form-group"><label>Email</label>
                    <input type="email" name="email" required></div>
                <div class="form-group"><label>Password</label>
                    <input type="password" name="password" required></div>
                <button type="submit" class="btn">Login</button>
            </form>
            <div class="links">
                <p>No account? <a href="register.php">Register here</a></p>
                <p><a href="../index.php">Back to Home</a></p>
            </div>
        </div>
    </div>
</body>
</html>
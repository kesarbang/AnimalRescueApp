<?php
session_start();
require_once '../includes/db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user = $_SESSION['user_name'];
$msg = "";

if(isset($_POST['submit'])){

$animal = $_POST['animal'];
$contact = $_POST['contact'];
$address = $_POST['address'];

$photo = $_FILES['photo']['name'];
$tmp = $_FILES['photo']['tmp_name'];

move_uploaded_file($tmp,"../uploads/".$photo);

$id = $_SESSION['user_id'];

$conn->query("INSERT INTO animal_reports(user_id,animal_type,contact_number,address,photo,status)
VALUES('$id','$animal','$contact','$address','$photo','Pending')");

$msg="Animal Report Uploaded Successfully";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>User Dashboard</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600;700;800&display=swap" rel="stylesheet">

<style>
body{
font-family:Inter,sans-serif;
background:#f4f5f7;
margin:0;
}
.container{
width:92%;
max-width:1400px;
margin:auto;
}
header{
padding:25px 0;
display:flex;
justify-content:space-between;
align-items:center;
}
.logo{
font-size:24px;
font-weight:800;
color:#0a57d5;
}
.nav a{
margin-left:20px;
text-decoration:none;
color:#111;
font-weight:600;
}
.hero{
display:grid;
grid-template-columns:1fr 1fr;
gap:50px;
align-items:center;
padding:40px 0;
}
.hero h1{
font-size:62px;
font-weight:800;
line-height:1.1;
}
.hero h1 span{
color:#0a57d5;
font-style:italic;
}
.hero p{
font-size:18px;
color:#555;
line-height:1.7;
}
.hero img{
width:100%;
height:500px;
object-fit:cover;
border-radius:28px;
}
.form-box{
background:#fff;
padding:35px;
border-radius:28px;
box-shadow:0 10px 30px rgba(0,0,0,.05);
margin:50px 0;
}
.form-box h2{
margin-bottom:25px;
font-size:36px;
}
input,textarea{
width:100%;
padding:14px;
margin-bottom:16px;
border:1px solid #ddd;
border-radius:14px;
font-size:15px;
}
button{
background:#0a57d5;
color:#fff;
border:none;
padding:15px 28px;
border-radius:28px;
font-weight:600;
cursor:pointer;
}
.success{
color:green;
margin-bottom:15px;
font-weight:600;
}
</style>
</head>

<body>

<div class="container">

<header>
<div class="logo">Rescue Sanctuary</div>

<div class="nav">
<span><?php echo $user; ?></span>
<a href="logout.php">Logout</a>
</div>
</header>

<div class="hero">

<div>
<h1>Help Save <span>Stray</span><br><span>Animals</span></h1>
<p>Report injured or stray animals instantly and help rescue teams respond faster.</p>
</div>

<div>
<img src="https://images.unsplash.com/photo-1548199973-03cce0bbc87b?auto=format&fit=crop&w=900&q=80">
</div>

</div>

<div class="form-box">

<h2>Upload Animal Report</h2>

<?php if($msg!=""){ ?>
<div class="success"><?php echo $msg; ?></div>
<?php } ?>

<form method="POST" enctype="multipart/form-data">

<input type="text" name="animal" placeholder="Animal Type" required>

<input type="text" name="contact" placeholder="Contact Number" required>

<textarea name="address" placeholder="Address" required></textarea>

<input type="file" name="photo" required>

<button type="submit" name="submit">Upload Report</button>

</form>

</div>

</div>
</body>
</html>
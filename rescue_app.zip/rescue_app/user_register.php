<?php include 'db.php'; ?>

<!DOCTYPE html>
<html>
<head>
<title>User Register</title>
<style>
body { font-family: Arial; background: #eef2f7; }
.container {
    width: 350px; margin: auto; padding: 20px;
    background: white; border-radius: 10px;
}
input, button {
    width: 100%; padding: 10px; margin: 10px 0;
}
button {
    background: #007bff; color: white; border: none;
}
</style>
</head>

<body>

<div class="container">
<h2>User Registration</h2>

<form method="POST">
<input type="text" name="name" placeholder="Name" required>
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>

<button type="submit" name="register">Register</button>
</form>

<?php
if(isset($_POST['register'])) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $pass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    $sql = "INSERT INTO users (name,email,password)
            VALUES ('$name','$email','$pass')";

    if($conn->query($sql)) {
        echo "Registration Successful";
    } else {
        echo "Error: " . $conn->error;
    }
}
?>
</div>

</body>
</html>
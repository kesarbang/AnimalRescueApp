document.addEventListener("DOMContentLoaded", function() {
    // -----------------------------------------------------
    // 1. Alert Messages
    // -----------------------------------------------------
    function showAlert(message, type = 'info') {
        const alertBox = document.createElement('div');
        alertBox.className = `alert alert-${type}`;
        alertBox.textContent = message;
        
        // Basic styling for alert to ensure visibility
        alertBox.style.position = 'fixed';
        alertBox.style.top = '20px';
        alertBox.style.right = '20px';
        alertBox.style.padding = '15px 20px';
        alertBox.style.borderRadius = '5px';
        alertBox.style.backgroundColor = type === 'error' ? '#f44336' : (type === 'success' ? '#4CAF50' : '#2196F3');
        alertBox.style.color = '#fff';
        alertBox.style.zIndex = '10000';
        alertBox.style.boxShadow = '0 2px 5px rgba(0,0,0,0.2)';
        alertBox.style.fontFamily = 'Arial, sans-serif';
        alertBox.style.transition = 'opacity 0.5s ease-out';
        
        document.body.appendChild(alertBox);
        
        setTimeout(() => {
            alertBox.style.opacity = '0';
            setTimeout(() => alertBox.remove(), 500);
        }, 3000);
    }

    // Expose globally if needed by inline scripts
    window.showAlert = showAlert;

    // -----------------------------------------------------
    // 2. Form Validation
    // -----------------------------------------------------
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', function(e) {
            let isValid = true;
            let errorMsgs = [];
            
            // Reusable validation function
            const validateField = (id, isImage = false, isPhone = false) => {
                const field = form.querySelector(`#${id}`);
                if (!field) return; 

                // Reset previous error display if any
                const errorDisplay = form.querySelector(`#${id}Error`);
                if (errorDisplay) errorDisplay.textContent = '';
                field.style.border = ''; // Reset border
                
                if (isImage && !field.value) {
                    isValid = false;
                    errorMsgs.push("Image upload is required.");
                    if (errorDisplay) errorDisplay.textContent = "Please select an image.";
                    field.style.border = '1px solid red';
                }
                else if (!isImage && field.value.trim() === '') {
                    isValid = false;
                    errorMsgs.push(`${id.charAt(0).toUpperCase() + id.slice(1)} is required.`);
                    if (errorDisplay) errorDisplay.textContent = `${id.charAt(0).toUpperCase() + id.slice(1)} is required.`;
                    field.style.border = '1px solid red';
                }
                else if (isPhone && !/^[0-9+\-\s()]{7,15}$/.test(field.value.trim())) {
                    isValid = false;
                    errorMsgs.push("Please enter a valid phone number.");
                    if (errorDisplay) errorDisplay.textContent = "Please enter a valid phone number.";
                    field.style.border = '1px solid red';
                }
            };

            // Trigger mapping for specific inputs often found in the rescue app
            validateField('image', true);
            validateField('description');
            validateField('location');
            validateField('contact', false, true);

            // Optional Admin login fields validation
            validateField('username');
            validateField('password');

            if (!isValid) {
                e.preventDefault();
                // Show only the first error as a toast alert for cleanliness
                showAlert(errorMsgs[0], "error");
            }
        });
    });

    // -----------------------------------------------------
    // 3. Simple Chatbot
    // -----------------------------------------------------
    const chatbotHTML = `
        <div id="chatbot-icon" style="position: fixed; bottom: 20px; right: 20px; width: 60px; height: 60px; background-color: #007bff; color: white; border-radius: 50%; display: flex; align-items: center; justify-content: center; cursor: pointer; box-shadow: 0 4px 8px rgba(0,0,0,0.2); z-index: 9999; font-size: 24px;">
            💬
        </div>
        <div id="chatbot-window" style="display: none; position: fixed; bottom: 90px; right: 20px; width: 320px; height: 420px; background-color: white; border-radius: 10px; box-shadow: 0 4px 12px rgba(0,0,0,0.15); z-index: 9999; flex-direction: column; overflow: hidden; font-family: Arial, sans-serif;">
            <div style="background-color: #007bff; color: white; padding: 15px; display: flex; justify-content: space-between; align-items: center;">
                <strong style="font-size: 16px;">Support Bot</strong>
                <span id="chatbot-close" style="cursor: pointer; font-size: 18px;">✖</span>
            </div>
            <div id="chatbot-messages" style="flex: 1; padding: 15px; overflow-y: auto; display: flex; flex-direction: column; gap: 10px; background-color: #f4f7f6;">
                <div style="background-color: #e2e8f0; color: #333; padding: 10px 14px; border-radius: 15px; border-bottom-left-radius: 0; align-self: flex-start; max-width: 80%; font-size: 14px; line-height: 1.4;">Hello! I am here to help. Type "report", "help", or "contact".</div>
            </div>
            <div style="padding: 10px; border-top: 1px solid #eee; display: flex; background: #fff;">
                <input type="text" id="chatbot-input" placeholder="Type a message..." style="flex: 1; padding: 10px; border: 1px solid #ddd; border-radius: 20px; outline: none; font-size: 14px;">
                <button id="chatbot-send" style="margin-left: 8px; padding: 0 15px; background-color: #007bff; color: white; border: none; border-radius: 20px; cursor: pointer; font-weight: bold; font-size: 14px;">Send</button>
            </div>
        </div>
    `;
    
    document.body.insertAdjacentHTML('beforeend', chatbotHTML);
    
    const icon = document.getElementById('chatbot-icon');
    const chatWindow = document.getElementById('chatbot-window');
    const closeBtn = document.getElementById('chatbot-close');
    const sendBtn = document.getElementById('chatbot-send');
    const inputField = document.getElementById('chatbot-input');
    const messagesContainer = document.getElementById('chatbot-messages');
    
    // Toggle chatbot
    icon.addEventListener('click', () => {
        chatWindow.style.display = chatWindow.style.display === 'none' || chatWindow.style.display === '' ? 'flex' : 'none';
        if (chatWindow.style.display === 'flex') {
            inputField.focus();
        }
    });
    
    closeBtn.addEventListener('click', () => {
        chatWindow.style.display = 'none';
    });
    
    function appendMessage(text, sender) {
        const msgDiv = document.createElement('div');
        msgDiv.style.padding = '10px 14px';
        msgDiv.style.maxWidth = '80%';
        msgDiv.style.wordWrap = 'break-word';
        msgDiv.style.fontSize = '14px';
        msgDiv.style.lineHeight = '1.4';
        
        if (sender === 'user') {
            msgDiv.textContent = text;
            msgDiv.style.backgroundColor = '#007bff';
            msgDiv.style.color = '#fff';
            msgDiv.style.borderRadius = '15px';
            msgDiv.style.borderBottomRightRadius = '0';
            msgDiv.style.alignSelf = 'flex-end';
        } else {
            // allowing basic newlines for bot
            msgDiv.innerHTML = text.replace(/\n/g, '<br>');
            msgDiv.style.backgroundColor = '#e2e8f0';
            msgDiv.style.color = '#333';
            msgDiv.style.borderRadius = '15px';
            msgDiv.style.borderBottomLeftRadius = '0';
            msgDiv.style.alignSelf = 'flex-start';
        }
        messagesContainer.appendChild(msgDiv);
        messagesContainer.scrollTop = messagesContainer.scrollHeight;
    }
    
    function processChatbotRules(input) {
        const text = input.toLowerCase().trim();
        let response = '';
        
        if (text.includes('report')) {
            response = 'To report a stray animal, navigate to the "Report" page. Please provide a picture, description, location, and your contact info.';
        } else if (text.includes('help')) {
            response = 'I can help you with the following commands:\n- "report" (how to report an animal)\n- "contact" (how to reach us)';
        } else if (text.includes('contact')) {
            response = 'You can reach out to our team at rescue@example.com or call our hotline at 1-800-RESCUE.';
        } else {
            response = 'I am a simple bot. Please type "help" to see what I can do.';
        }
        
        // Simulate typing delay
        setTimeout(() => {
            appendMessage(response, 'bot');
        }, 600);
    }
    
    function handleSend() {
        const text = inputField.value;
        if (text.trim() !== '') {
            appendMessage(text, 'user');
            inputField.value = '';
            processChatbotRules(text);
        }
    }

    sendBtn.addEventListener('click', handleSend);
    
    inputField.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') {
            handleSend();
        }
    });

});

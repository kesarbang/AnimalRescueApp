<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header("Location: login.php");
    exit();
}

require_once '../includes/db.php';
require_once '../includes/header.php';

// Fetch all reports
$query = "SELECT * FROM reports ORDER BY created_at DESC";
$result = mysqli_query($conn, $query);

// Fetch counts for statistics
$res_pending = mysqli_query($conn, "SELECT COUNT(*) as count FROM reports WHERE status = 'Pending'");
$row_pending = mysqli_fetch_assoc($res_pending);
$pending_count = $row_pending ? $row_pending['count'] : 0;

$res_in_progress = mysqli_query($conn, "SELECT COUNT(*) as count FROM reports WHERE status = 'In Progress'");
$row_in_progress = mysqli_fetch_assoc($res_in_progress);
$in_progress_count = $row_in_progress ? $row_in_progress['count'] : 0;

$res_rescued = mysqli_query($conn, "SELECT COUNT(*) as count FROM reports WHERE status = 'Rescued'");
$row_rescued = mysqli_fetch_assoc($res_rescued);
$rescued_count = $row_rescued ? $row_rescued['count'] : 0;

$active_count = $pending_count + $in_progress_count;
?>

<style>
/* Modern Dashboard Reset and Setup */
.dashboard-wrapper {
    position: fixed;
    top: 0;
    left: 0;
    width: 100vw;
    height: 100vh;
    background: #f8fafc;
    z-index: 9999;
    display: flex;
    overflow: hidden;
    font-family: 'Inter', -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
}

/* Sidebar */
.sidebar {
    width: 260px;
    background-color: #ffffff;
    border-right: 1px solid #e2e8f0;
    display: flex;
    flex-direction: column;
    height: 100vh;
}

.sidebar-header {
    padding: 24px;
    border-bottom: 1px solid #f1f5f9;
}

.sidebar-header h2 {
    margin: 0;
    color: #1e3a8a;
    font-size: 20px;
    font-weight: 700;
}

.sidebar-header p {
    margin: 4px 0 0;
    color: #64748b;
    font-size: 13px;
}

.sidebar-menu {
    list-style: none;
    padding: 24px 0;
    margin: 0;
    flex: 1;
}

.sidebar-menu li {
    padding: 0 16px;
    margin-bottom: 4px;
}

.sidebar-menu a {
    display: flex;
    align-items: center;
    padding: 12px 16px;
    color: #64748b;
    text-decoration: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    transition: all 0.2s;
}

.sidebar-menu a:hover {
    color: #1e3a8a;
    background-color: #f1f5f9;
}

.sidebar-menu a.active {
    color: #1e3a8a;
    background-color: #eff6ff;
    border-left: 3px solid #3b82f6;
}

.sidebar-menu a span {
    margin-right: 12px;
    font-size: 18px;
}

.sidebar-footer {
    padding: 24px 16px;
}

.btn-emergency {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 100%;
    padding: 12px;
    background-color: #dc2626;
    color: #ffffff;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    font-size: 15px;
    cursor: pointer;
    text-decoration: none;
    transition: background-color 0.2s;
}

.btn-emergency:hover {
    background-color: #b91c1c;
}

.btn-emergency span {
    margin-right: 8px;
}

/* Main Content */
.main-content {
    flex: 1;
    padding: 40px;
    overflow-y: auto;
    height: 100vh;
    box-sizing: border-box;
}

/* Header */
.top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 40px;
}

.page-title h1 {
    margin: 0;
    font-size: 28px;
    color: #0f172a;
    font-weight: 700;
    letter-spacing: -0.5px;
}

.page-title p {
    margin: 8px 0 0;
    color: #64748b;
    font-size: 15px;
}

.top-actions {
    display: flex;
    align-items: center;
    gap: 16px;
}

.search-container {
    position: relative;
}

.search-input {
    padding: 10px 16px 10px 40px;
    border: 1px solid #e2e8f0;
    border-radius: 24px;
    background-color: #f1f5f9;
    color: #334155;
    font-size: 14px;
    width: 250px;
    outline: none;
    transition: all 0.2s;
}
.search-input:focus {
    background-color: #ffffff;
    border-color: #cbd5e1;
    box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.1);
}

.search-icon {
    position: absolute;
    left: 14px;
    top: 50%;
    transform: translateY(-50%);
    color: #64748b;
}

.notification-btn {
    width: 40px;
    height: 40px;
    border-radius: 50%;
    background-color: #f1f5f9;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 1px solid #e2e8f0;
    cursor: pointer;
    font-size: 18px;
    color: #475569;
    position: relative;
}

.notification-badge {
    position: absolute;
    top: 10px;
    right: 12px;
    width: 8px;
    height: 8px;
    background-color: #ef4444;
    border-radius: 50%;
}

/* Statistics Cards */
.stats-container {
    display: grid;
    grid-template-columns: repeat(4, 1fr);
    gap: 24px;
    margin-bottom: 40px;
}

.stat-card {
    background: #ffffff;
    border-radius: 16px;
    padding: 24px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    border: 1px solid #e2e8f0;
    display: flex;
    flex-direction: column;
}

.stat-title {
    font-size: 12px;
    text-transform: uppercase;
    font-weight: 700;
    color: #475569;
    letter-spacing: 0.5px;
    margin-bottom: 12px;
}

.stat-val {
    font-size: 36px;
    font-weight: 700;
    color: #0f172a;
    display: flex;
    align-items: baseline;
    gap: 8px;
}

.stat-change {
    font-size: 14px;
    font-weight: 600;
    color: #10b981;
}

.stat-orange {
    color: #ea580c;
}

.stat-blue {
    background: linear-gradient(135deg, #0284c7 0%, #1e3a8a 100%);
    border: none;
    box-shadow: 0 10px 15px -3px rgba(2, 132, 199, 0.3);
}

.stat-blue .stat-title {
    color: rgba(255, 255, 255, 0.8);
}

.stat-blue .stat-val {
    color: #ffffff;
}

/* Reports Table Section */
.table-section {
    background: #ffffff;
    border-radius: 16px;
    box-shadow: 0 1px 3px rgba(0,0,0,0.05);
    border: 1px solid #e2e8f0;
    overflow: hidden;
}

.table-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 24px;
    border-bottom: 1px solid #e2e8f0;
}

.table-header h2 {
    margin: 0;
    font-size: 18px;
    color: #0f172a;
    font-weight: 600;
}

.table-controls {
    display: flex;
    gap: 12px;
}

.btn-outline {
    padding: 8px 16px;
    border: 1px solid #e2e8f0;
    background: #ffffff;
    border-radius: 8px;
    color: #1e3a8a;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
}

.btn-primary {
    padding: 8px 16px;
    background: #1e3a8a;
    color: #ffffff;
    border: none;
    border-radius: 8px;
    font-weight: 600;
    font-size: 14px;
    cursor: pointer;
}

.rescues-table {
    width: 100%;
    border-collapse: collapse;
}

.rescues-table th {
    background-color: #f8fafc;
    text-align: left;
    padding: 16px 24px;
    font-size: 12px;
    font-weight: 700;
    color: #64748b;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    border-bottom: 1px solid #e2e8f0;
}

.rescues-table td {
    padding: 20px 24px;
    border-bottom: 1px solid #e2e8f0;
    vertical-align: middle;
}

.rescues-table tr:hover {
    background-color: #f8fafc;
}

.rescues-table tr:last-child td {
    border-bottom: none;
}

/* Table Cell Styling */
.animal-info {
    display: flex;
    align-items: center;
    gap: 16px;
    min-width: 200px;
}

.animal-img {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    object-fit: cover;
}

.no-img {
    width: 48px;
    height: 48px;
    border-radius: 50%;
    background-color: #e2e8f0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 20px;
}

.animal-details h4 {
    margin: 0 0 6px;
    font-size: 14px;
    font-weight: 600;
    color: #0f172a;
}

.animal-tags {
    display: flex;
    gap: 8px;
}

.tag {
    padding: 2px 8px;
    border-radius: 12px;
    font-size: 11px;
    font-weight: 600;
    text-transform: uppercase;
    background-color: #f1f5f9;
    color: #475569;
}

.tag-injured {
    background-color: #ffedd5;
    color: #c2410c;
}

.cell-primary {
    font-size: 14px;
    font-weight: 600;
    color: #0f172a;
    margin-bottom: 4px;
}

.cell-secondary {
    font-size: 13px;
    color: #64748b;
}

/* Badges */
.status-badge {
    padding: 6px 12px;
    border-radius: 20px;
    font-size: 12px;
    font-weight: 600;
    display: inline-block;
}

.status-pending {
    background-color: #ffedd5;
    color: #9a3412;
}

.status-in-progress {
    background-color: #e0f2fe;
    color: #0369a1;
}

.status-rescued {
    background-color: #dcfce3;
    color: #15803d;
}

/* Form Actions */
.action-form {
    display: flex;
    align-items: center;
    gap: 12px;
    margin: 0;
}

.status-select {
    padding: 6px 10px;
    border-radius: 6px;
    border: 1px solid #cbd5e1;
    font-size: 13px;
    color: #334155;
    background-color: white;
    cursor: pointer;
    font-family: inherit;
    font-weight: 500;
}

.btn-icon-actions {
    display: flex;
    gap: 6px;
}

.btn-icon {
    width: 30px;
    height: 30px;
    border-radius: 6px;
    display: flex;
    align-items: center;
    justify-content: center;
    border: none;
    cursor: pointer;
    background-color: transparent;
    font-size: 14px;
    transition: background-color 0.2s;
    text-decoration: none;
}

.btn-icon:hover {
    background-color: #f1f5f9;
}

.btn-update { color: #10b981; }
.btn-view { color: #3b82f6; }
.btn-delete { color: #ef4444; }

</style>

<div class="dashboard-wrapper">
    <!-- Sidebar -->
    <aside class="sidebar">
        <div class="sidebar-header">
            <h2>Rescue Admin</h2>
            <p>Management Portal</p>
        </div>
        <ul class="sidebar-menu">
            <li><a href="dashboard.php" class="active"><span>📊</span> Dashboard</a></li>
        </ul>
    </aside>

    <!-- Main Content -->
    <main class="main-content">
        <!-- Top Header -->
        <header class="top-bar">
            <div class="page-title">
                <h1>Rescue Operations</h1>
                <p>Real-time status of stray animal reports and field responses.</p>
            </div>
            <div class="top-actions">
                <div class="search-container">
                    <span class="search-icon">🔍</span>
                    <input type="text" class="search-input" placeholder="Search reports...">
                </div>
                <button class="notification-btn">
                    🔔
                    <span class="notification-badge"></span>
                </button>
            </div>
        </header>

        <!-- Stats -->
        <div class="stats-container">
            <div class="stat-card">
                <div class="stat-title">Active Reports</div>
                <div class="stat-val"><?php echo sprintf("%02d", $active_count); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-title">In Transit</div>
                <div class="stat-val stat-orange"><?php echo sprintf("%02d", $in_progress_count); ?></div>
            </div>
            <div class="stat-card">
                <div class="stat-title">Pending Review</div>
                <div class="stat-val"><?php echo sprintf("%02d", $pending_count); ?></div>
            </div>
            <div class="stat-card stat-blue">
                <div class="stat-title">Rescued Today</div>
                <div class="stat-val"><?php echo sprintf("%02d", $rescued_count); ?> <span>🐾</span></div>
            </div>
        </div>

        <!-- Reports Table -->
        <div class="table-section">
            <div class="table-header">
                <h2>Recent Incident Reports</h2>
                <div class="table-controls">
                </div>
            </div>
            
            <table class="rescues-table">
                <thead>
                    <tr>
                        <th>Animal Info</th>
                        <th>Location</th>
                        <th>Reporter</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0): ?>
                        <?php while ($row = mysqli_fetch_assoc($result)): ?>
                            <tr>
                                <td>
                                    <div class="animal-info">
                                        <?php if (!empty($row['image'])): ?>
                                            <img src="../<?php echo htmlspecialchars($row['image']); ?>" alt="Animal" class="animal-img">
                                        <?php else: ?>
                                            <div class="no-img">🐾</div>
                                        <?php endif; ?>
                                        <div class="animal-details">
                                            <h4><?php echo htmlspecialchars(substr($row['description'], 0, 30)) . (strlen($row['description']) > 30 ? '...' : ''); ?></h4>
                                            <div class="animal-tags">
                                                <span class="tag tag-injured">REPORTED</span>
                                                <span class="tag">URGENT</span>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="cell-primary"><?php echo htmlspecialchars($row['location']); ?></div>
                                    <div class="cell-secondary"><?php echo date('M d, Y', strtotime($row['created_at'])); ?> &bull; <?php echo date('g:i A', strtotime($row['created_at'])); ?></div>
                                </td>
                                <td>
                                    <div class="cell-primary"><?php echo htmlspecialchars($row['contact']); ?></div>
                                    <div class="cell-secondary">Verified Reporter</div>
                                </td>
                                <td>
                                    <?php 
                                        $db_status = $row['status'];
                                        $disp_status = $db_status;
                                        if ($db_status === 'Pending') $disp_status = 'Pending Response';
                                        if ($db_status === 'In Progress') $disp_status = 'In Transit';
                                        
                                        $badge_class = 'status-' . strtolower(str_replace(' ', '-', $db_status));
                                    ?>
                                    <span class="status-badge <?php echo $badge_class; ?>">
                                        <?php echo htmlspecialchars($disp_status); ?>
                                    </span>
                                </td>
                                <td>
                                    <form action="../actions/update_status.php" method="POST" class="action-form">
                                        <input type="hidden" name="report_id" value="<?php echo $row['id']; ?>">
                                        <select name="status" class="status-select">
                                            <option value="Pending" <?php echo ($row['status'] == 'Pending') ? 'selected' : ''; ?>>Pending Response</option>
                                            <option value="In Progress" <?php echo ($row['status'] == 'In Progress') ? 'selected' : ''; ?>>In Transit</option>
                                            <option value="Rescued" <?php echo ($row['status'] == 'Rescued') ? 'selected' : ''; ?>>Rescued</option>
                                        </select>
                                        <div class="btn-icon-actions">
                                            <button type="submit" class="btn-icon btn-update" title="Update Status">✔️</button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    <?php else: ?>
                        <tr>
                            <td colspan="5" style="text-align: center; padding: 40px; color: #64748b;">No active reports found.</td>
                        </tr>
                    <?php endif; ?>
                </tbody>
            </table>
        </div>
    </main>
</div>

<?php require_once '../includes/footer.php'; ?>

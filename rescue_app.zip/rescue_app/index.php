<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pet Rescue Web App</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header>
        <div class="container">
            <a href="index.php">Pet Rescue System</a>
        </div>
    </header>

    <div class="main-content">
        <div class="container cards-wrapper">
            <div class="home-card">
                <h2>I am a User</h2>
                <p>Report animals, view rescue status.</p>
                <a href="user/login.php" class="btn">User Portal</a>
            </div>
            
            <div class="home-card">
                <h2>I am an NGO</h2>
                <p>Manage rescue requests and updates.</p>
                <a href="ngo/login.php" class="btn">NGO Portal</a>
            </div>
        </div>
    </div>
</body>
</html>

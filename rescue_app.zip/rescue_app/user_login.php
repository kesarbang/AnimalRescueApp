<?php include 'db.php'; session_start(); ?>

<!DOCTYPE html>
<html>
<head>
<title>User Login</title>
</head>

<body>

<form method="POST">
<input type="email" name="email" placeholder="Email" required>
<input type="password" name="password" placeholder="Password" required>

<button name="login">Login</button>
</form>

<?php
if(isset($_POST['login'])) {
    $email = $_POST['email'];
    $pass = $_POST['password'];

    $res = $conn->query("SELECT * FROM users WHERE email='$email'");
    $user = $res->fetch_assoc();

    if($user && password_verify($pass, $user['password'])) {
        $_SESSION['user'] = $user['id'];
        echo "Login Success";
    } else {
        echo "Invalid Credentials";
    }
}
?>

</body>
</html>